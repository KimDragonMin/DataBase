import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LogInFrame extends JFrame {
    private JTextField UserIDField;
    private JPasswordField PasswordField;
    private JTextField NickNameField;
    public LogInFrame() {
        setTitle("Log In");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                GUI.showGUI(); // 창을 닫을 때 메인 GUI 다시 표시
            }
        });
    }

    private void initUI() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(5, 5, 5, 5);
        JLabel usernameLabel = new JLabel("아이디:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(usernameLabel, constraints);
        UserIDField = new JTextField(15);
        constraints.gridx = 1;
        panel.add(UserIDField, constraints);
        JLabel passwordLabel = new JLabel("비밀번호:");
        constraints.gridx = 0;
        constraints.gridy = 1;
        panel.add(passwordLabel, constraints);
        PasswordField = new JPasswordField(15);
        constraints.gridx = 1;
        panel.add(PasswordField, constraints);
        JButton logInButton = new JButton("로그인");
        logInButton.addActionListener(e -> logIn());
        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(logInButton, constraints);
        add(panel);

        getRootPane().setDefaultButton(logInButton);  // 로그인 버튼을 기본 버튼으로 설정
    }
    private void logIn() {
        String UserID = UserIDField.getText();
        char[] PasswordChars = PasswordField.getPassword();
        String Password = new String(PasswordChars);
        try {
            String NickName = validateUser(UserID, Password);
            if (NickName != null) {
                JOptionPane.showMessageDialog(this, "로그인 성공");
                openMainApplication(NickName, UserID); // 닉네임을 전달
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "로그인 실패. 다시 확인해주세요.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void openMainApplication(String NickName, String UserID) {
        PersonalizedFrame mainFrame = new PersonalizedFrame(NickName, UserID); // 닉네임을 사용해 PersonalizedFrame 생성
        mainFrame.setVisible(true);
        dispose();
    }

    private String validateUser(String UserID, String Password) throws Exception {
        String driver = "oracle.jdbc.OracleDriver";
        String url = "jdbc:oracle:thin:@203.234.62.88:1521:xe";
        String username = "c##project";
        String password = "1234";
        Class.forName(driver);
        Connection db = DriverManager.getConnection(url, username, password);
        String sql = "SELECT * FROM Players WHERE UserID = ? AND Password = ?";
        try (PreparedStatement preparedStatement = db.prepareStatement(sql)) {
            preparedStatement.setString(1, UserID);
            preparedStatement.setString(2, Password);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("NickName");  // 닉네임을 반환
            }
        } finally {
            db.close();
        }
        return null;
    }

}