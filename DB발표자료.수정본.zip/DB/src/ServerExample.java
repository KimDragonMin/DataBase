import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ServerExample {
    public static void main(String[] args) {
        try {
            // 서버 소켓 생성
            ServerSocket serverSocket = new ServerSocket(5000);

            System.out.println("서버가 시작되었습니다.");

            while (true) {
                // 클라이언트의 연결을 기다림
                Socket clientSocket = serverSocket.accept();
                System.out.println("클라이언트가 연결되었습니다.");

                // 클라이언트와의 입출력 스트림을 얻음
                InputStream inputStream = clientSocket.getInputStream();
                OutputStream outputStream = clientSocket.getOutputStream();

                // 클라이언트로부터의 메시지를 받음
                byte[] buffer = new byte[1024];
                int bytesRead = inputStream.read(buffer);
                String message = new String(buffer, 0, bytesRead);
                System.out.println("클라이언트로부터의 메시지: " + message);

                // 데이터베이스 연결
                String url = "jdbc:oracle:thin:@localhost:1522:XE";
                String username = "c##project";
                String password = "1234";
                Connection connection = DriverManager.getConnection(url, username, password);

                // 쿼리 실행
                String sql = "SELECT * FROM Players";
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql);

                // 결과 처리
                StringBuilder resultBuilder = new StringBuilder();
                while (resultSet.next()) {
                    // 결과 데이터 처리
                    String column1Data = resultSet.getString("열1이름");
                    String column2Data = resultSet.getString("열2이름");

                    // 결과를 문자열로 추가
                    resultBuilder.append("열1 데이터: ").append(column1Data).append("\n");
                    resultBuilder.append("열2 데이터: ").append(column2Data).append("\n");
                }

                // 결과를 클라이언트에게 전송
                String response = resultBuilder.toString();
                outputStream.write(response.getBytes());

                // 연결 종료
                resultSet.close();
                statement.close();
                connection.close();

                // 클라이언트 소켓 종료
                clientSocket.close();
                System.out.println("클라이언트와의 연결이 종료되었습니다.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}