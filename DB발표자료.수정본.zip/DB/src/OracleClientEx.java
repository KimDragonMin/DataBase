import java.io.*;
import java.net.*;
import java.sql.*;

import javax.swing.SwingUtilities;

public class OracleClientEx {
    public static void main(String[] args) {
        // 서버 정보
        String serverIP = "203.234.62.88";
        int serverPort = 5000;
        
        try {
            // 서버에 연결
            Socket socket = new Socket(serverIP, serverPort);
            System.out.println("서버에 연결되었습니다.");
            
            // 데이터베이스 연결 정보
            String url = "jdbc:oracle:thin:@203.234.62.88:1521:xe";
            String username = "c##project";
            String password = "1234";
            
            // Oracle JDBC 드라이버 로드
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            // 데이터베이스 연결
            Connection connection = DriverManager.getConnection(url, username, password);
            System.out.println("데이터베이스에 연결되었습니다.");
            
            GUI gui = new GUI();
            gui.setVisible(true);
            
            // 서버로부터 입력 받기
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String sql = reader.readLine(); // 서버에서 전송한 SQL 쿼리
            
            // SQL 쿼리 실행
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            
            
            // 자원 해제
            resultSet.close();
            statement.close();
            connection.close();
            
            // 소켓 연결 종료
            socket.close();
            System.out.println("서버 연결을 종료했습니다.");
            
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
