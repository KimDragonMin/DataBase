import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PersonalizedFrame extends JFrame {
    private String userID;
    private JPanel websiteButtonPanel;

    public PersonalizedFrame(String NickName, String UserID) {
        this.userID = UserID;

        setLayout(new BorderLayout());
        JLabel userNameLabel = new JLabel("사용자: " + NickName);

        JPanel userNamePanel = new JPanel();
        userNamePanel.add(userNameLabel);
        add(userNamePanel, BorderLayout.NORTH);

        JButton addButton = new JButton("+");
        addButton.addActionListener(new AddButtonListener());

        JButton removeButton = new JButton("-");
        removeButton.addActionListener(new RemoveButtonListener());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(300, 200)); // 버튼 패널의 크기를 300x200으로 설정
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        add(buttonPanel, BorderLayout.CENTER);

        websiteButtonPanel = new JPanel();
        add(websiteButtonPanel, BorderLayout.SOUTH);

        loadUserUrls();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600, 900);

        setVisible(true);
    }

    private void addUserUrl(String UserID, String url) throws Exception {
        String driver = "oracle.jdbc.driver.OracleDriver";
        String dbUrl = "jdbc:oracle:thin:@203.234.62.88:1521:XE";
        String user = "c##project";
        String dbPassword = "1234";
        Class.forName(driver);
        Connection db = DriverManager.getConnection(dbUrl, user, dbPassword);
        String sql = "INSERT INTO UserUrls (UserID, Url) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = db.prepareStatement(sql)) {
            preparedStatement.setString(1, UserID);
            preparedStatement.setString(2, url);
            preparedStatement.executeUpdate();
        } finally {
            db.close();
        }
    }

    private void removeUserUrl(String UserID, String url) throws Exception {
        String driver = "oracle.jdbc.driver.OracleDriver";
        String dbUrl = "jdbc:oracle:thin:@203.234.62.88:1521:XE";
        String user = "c##project";
        String dbPassword = "1234";
        Connection db = null;
        try {
            Class.forName(driver);
            db = DriverManager.getConnection(dbUrl, user, dbPassword);
            String sql = "DELETE FROM UserUrls WHERE UserID = ? AND Url = ?";
            try (PreparedStatement preparedStatement = db.prepareStatement(sql)) {
                preparedStatement.setString(1, UserID);
                preparedStatement.setString(2, url);
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                try {
                    db.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void loadUserUrls() {
        List<String> urls = getUserUrlsFromDatabase(userID);
        for (String url : urls) {
            JButton websiteButton = new JButton(url);
            websiteButton.addActionListener(new WebsiteButtonListener(url));
            websiteButtonPanel.add(websiteButton);
        }
        revalidate();
        repaint();
    }

    private List<String> getUserUrlsFromDatabase(String userID) {
        List<String> urls = new ArrayList<>();
        String driver = "oracle.jdbc.driver.OracleDriver";
        String dbUrl = "jdbc:oracle:thin:@203.234.62.88:1521:XE";
        String user = "c##project";
        String dbPassword = "1234";
        Connection db = null;
        try {
            Class.forName(driver);
            db = DriverManager.getConnection(dbUrl, user, dbPassword);
            String sql = "SELECT Url FROM UserUrls WHERE UserID = ?";
            try (PreparedStatement preparedStatement = db.prepareStatement(sql)) {
                preparedStatement.setString(1, userID);
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    String url = resultSet.getString("Url");
                    urls.add(url);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                try {
                    db.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return urls;
    }

    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String url = JOptionPane.showInputDialog("URL을 입력하세요:");
            if (url != null && !url.isEmpty()) {
                try {
                    addUserUrl(userID, url);
                    JButton websiteButton = new JButton(url);
                    websiteButton.addActionListener(new WebsiteButtonListener(url));
                    websiteButtonPanel.add(websiteButton);
                    revalidate();
                    repaint();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private class RemoveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String[] options = getUserUrlsFromDatabase(userID).toArray(new String[0]);
            String selectedUrl = (String) JOptionPane.showInputDialog(null, "삭제할 URL을 선택하세요:", "URL 선택", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
            if (selectedUrl != null) {
                try {
                    removeUserUrl(userID, selectedUrl);
                    for (Component component : websiteButtonPanel.getComponents()) {
                        if (component instanceof JButton) {
                            JButton websiteButton = (JButton) component;
                            if (websiteButton.getText().equals(selectedUrl)) {
                                websiteButtonPanel.remove(websiteButton);
                                break;
                            }
                        }
                    }
                    revalidate();
                    repaint();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private class WebsiteButtonListener implements ActionListener {
        private final String url;

        public WebsiteButtonListener(String url) {
            this.url = url;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().browse(new URI(url));
                } catch (IOException | URISyntaxException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}